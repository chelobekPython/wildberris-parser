// content.js — for search pages

chrome.runtime.sendMessage({ action: 'content_ready' });

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'get_product_links') {
    const max = request.max || 10;
    const links = getProductLinks(max);
    sendResponse({ links });
  }
  return true;
});

function getProductLinks(maxCount = 10) {
  const links = [];
  // Aggressive search for product links
  const allLinks = document.querySelectorAll('a[href*="/catalog/"][href*="detail.aspx"]');
  allLinks.forEach(a => {
    const href = a.href;
    if (href && href.includes('/detail.aspx') && !links.includes(href)) {
      links.push(href);
      if (links.length >= maxCount) return;
    }
  });
  return links;
}
