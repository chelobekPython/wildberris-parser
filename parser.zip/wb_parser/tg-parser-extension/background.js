let collectedData = [];
let productLinks = [];
let currentIndex = 0;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'start_parse') {
    productLinks = request.links; // No limit, use all collected links
    collectedData = [];
    currentIndex = 0;
    chrome.runtime.sendMessage({ action: 'parse_progress', text: `Parsing 1 of ${productLinks.length}...` });
    parseNextProduct();
    sendResponse({ status: 'started' });
  } else if (request.action === 'detail_parsed') {
    collectedData.push(request.data);
    currentIndex++;
    if (currentIndex < productLinks.length) {
      chrome.runtime.sendMessage({ action: 'parse_progress', text: `Parsing ${currentIndex + 1} of ${productLinks.length}...` });
      setTimeout(parseNextProduct, 4000 + Math.random() * 2000);
    } else {
      chrome.runtime.sendMessage({ action: 'all_parsed', data: collectedData });
    }
  }
  return true;
});

function parseNextProduct() {
  const link = productLinks[currentIndex];
  chrome.tabs.create({ url: link, active: false }, async (tab) => {
    try {
      // Wait for page load
      await new Promise(resolve => {
        const listener = (tabId, changeInfo) => {
          if (tabId === tab.id && changeInfo.status === 'complete') {
            chrome.tabs.onUpdated.removeListener(listener);
            resolve();
          }
        };
        chrome.tabs.onUpdated.addListener(listener);
      });

      // Manually inject detail_content.js since manifest injection might not work reliably for created tabs
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['detail_content.js']
      });

      // Wait a bit for the script to initialize
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Now send parse request
      chrome.tabs.sendMessage(tab.id, { action: 'parse_detail' }, (response) => {
        chrome.runtime.sendMessage({ action: 'detail_parsed', data: response || { error: 'No data received' } });
        chrome.tabs.remove(tab.id);
      });

    } catch (error) {
      chrome.runtime.sendMessage({ action: 'detail_parsed', data: { error: 'Injection failed: ' + error.message, link } });
      chrome.tabs.remove(tab.id);
    }
  });
}
