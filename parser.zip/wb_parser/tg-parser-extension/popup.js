let allProductLinks = [];
let currentPage = 0;
let totalPages = 1;
let maxProductsPerPage = 10;
let logs = [];

// Tab switching
document.querySelectorAll('.tab-button').forEach(button => {
  button.addEventListener('click', () => {
    const tabName = button.dataset.tab;
    document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    button.classList.add('active');
    document.getElementById(tabName + '-tab').classList.add('active');
  });
});

// Clear logs
document.getElementById('clearLogsButton').addEventListener('click', () => {
  logs = [];
  updateLogsDisplay();
});

function log(message, type = 'info') {
  const timestamp = new Date().toLocaleTimeString();
  const entry = `[${timestamp}] ${message}`;
  logs.push({ message: entry, type });
  console.log(`[${type.toUpperCase()}] ${message}`);
  updateLogsDisplay();
}

function updateLogsDisplay() {
  const logsDiv = document.getElementById('logs');
  logsDiv.innerHTML = logs.map(entry => `<div class="log-entry log-${entry.type}">${entry.message}</div>`).join('');
  logsDiv.scrollTop = logsDiv.scrollHeight;
}

document.getElementById('parseButton').addEventListener('click', async () => {
  const statusEl = document.getElementById('status');
  const progressBar = document.querySelector('.progress-bar');
  const progressFill = document.getElementById('progressFill');
  const button = document.getElementById('parseButton');

  // Get settings
  totalPages = parseInt(document.getElementById('pagesCount').value) || 1;
  maxProductsPerPage = parseInt(document.getElementById('maxProducts').value) || 10;

  // Reset
  allProductLinks = [];
  currentPage = 0;
  button.disabled = true;
  progressBar.style.display = 'block';
  statusEl.textContent = 'Checking current page...';
  statusEl.className = '';

  log('Starting parsing process');
  try {
    // Get active tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    log(`Active tab: ${tab.url}`);

    // Check if it's Wildberries
    if (!tab.url.includes('wildberries.ru')) {
      throw new Error('Please open a Wildberries search page first');
    }

    // Start parsing pages
    await parseNextPage(tab.url);

  } catch (error) {
    log(`Error: ${error.message}`, 'error');
    statusEl.textContent = 'Error: ' + error.message;
    statusEl.className = 'error';
    button.disabled = false;
    progressBar.style.display = 'none';
  }
});

async function parseNextPage(baseUrl) {
  currentPage++;
  const statusEl = document.getElementById('status');
  const progressFill = document.getElementById('progressFill');

  log(`Parsing page ${currentPage} of ${totalPages}`);
  statusEl.textContent = `Parsing page ${currentPage} of ${totalPages}...`;

  // Construct page URL
  let pageUrl = baseUrl;
  if (currentPage > 1) {
    // Add page parameter to URL
    const url = new URL(baseUrl);
    url.searchParams.set('page', currentPage);
    pageUrl = url.toString();
  }

  log(`Opening page: ${pageUrl}`);
  // Open or navigate to the page
  const tab = await chrome.tabs.create({ url: pageUrl, active: false });

  // Wait for page load
  await new Promise(resolve => {
    const listener = (tabId, changeInfo) => {
      if (tabId === tab.id && changeInfo.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });

  log('Page loaded, injecting content script');
  // Inject content script
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ['content.js']
  });

  log('Getting product links');
  // Get product links
  const response = await chrome.tabs.sendMessage(tab.id, { action: 'get_product_links', max: maxProductsPerPage });

  if (response && response.links && response.links.length > 0) {
    allProductLinks.push(...response.links);
    log(`Found ${response.links.length} links on page ${currentPage}, total: ${allProductLinks.length}`);
    statusEl.textContent = `Found ${response.links.length} products on page ${currentPage}. Total: ${allProductLinks.length}`;
  } else {
    log('No links found on this page', 'error');
  }

  // Close the tab
  chrome.tabs.remove(tab.id);

  // Update progress
  const progress = (currentPage / totalPages) * 100;
  progressFill.style.width = progress + '%';

  // Parse next page or start product parsing
  if (currentPage < totalPages) {
    log('Moving to next page');
    setTimeout(() => parseNextPage(baseUrl), 2000); // Delay between pages
  } else {
    log(`Collected ${allProductLinks.length} total links, starting product parsing`);
    statusEl.textContent = `Collected ${allProductLinks.length} product links. Starting detail parsing...`;
    // Start parsing product details
    chrome.runtime.sendMessage({ action: 'start_parse', links: allProductLinks });
  }
}

// Listen for messages from background
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const statusEl = document.getElementById('status');
  const button = document.getElementById('parseButton');
  const progressBar = document.querySelector('.progress-bar');

  if (request.action === 'parse_progress') {
    log(`Progress: ${request.text}`);
    statusEl.textContent = request.text;
  } else if (request.action === 'all_parsed') {
    log(`All parsing completed, ${request.data ? request.data.length : 0} products parsed`);
    statusEl.textContent = 'Parsing completed. Sending to Telegram...';
    sendToTelegram({ products: request.data });
    // Reset UI
    button.disabled = false;
    progressBar.style.display = 'none';
  }
});

// Send data to Telegram with safe encoding
function sendToTelegram(data) {
  log('Preparing Telegram message');
  let message = '';
  const products = data.products || data;

  if (products && products.length > 0) {
    message = `Detailed data for ${products.length} products:\n\n`;
    for (let i = 0; i < products.length; i++) {
      const p = products[i];
      const productText = `${i+1}. ${p.name || 'Untitled'} (${p.brand})\n` +
        `Price: ${p.price} ${p.currency}` +
        (p.oldPrice !== '-' ? ` (was ${p.oldPrice})` : '') +
        `\nRating: ${p.rating} ⭐ | Reviews: ${p.reviewsCount}\n` +
        (p.description ? `${p.description.substring(0, 150)}...\n` : '') +
        (Object.keys(p.specs).length > 0 ? Object.entries(p.specs).slice(0, 4).map(([k, v]) => `${k}: ${v}`).join(' | ') + '\n' : '') +
        `Seller: ${p.seller}\n${p.link}\n\n`;

      // Check if adding this would exceed limit
      if (message.length + productText.length > 3500) {
        log(`Message too long at product ${i+1}, truncating`);
        message += `\n... (${products.length - i} more products truncated due to message length limit)`;
        break;
      }
      message += productText;
    }
  } else {
    message = "No products parsed.";
  }

  log(`Message length: ${message.length} characters`);
  const botToken = 'PASTE_YOUR_API_KEY';
  const chatId = 'PASTE_YOUR_CHAT_ID-----';
  const url = `https://api.telegram.org/bot${botToken}/sendMessage?chat_id=${chatId}&text=${encodeURIComponent(message)}&disable_web_page_preview=true`;

  const statusEl = document.getElementById('status');
  statusEl.textContent = 'Sending to Telegram...';
  log('Sending to Telegram API');

  fetch(url)
    .then(r => {
      log(`Telegram API response status: ${r.status}`);
      return r.json();
    })
    .then(res => {
      log(`Telegram response: ${JSON.stringify(res)}`);
      if (res.ok) {
        log('Successfully sent to Telegram', 'success');
        statusEl.textContent = 'Successfully sent to Telegram!';
        statusEl.className = 'success';
      } else {
        log(`Telegram error: ${res.description || res.error_code}`, 'error');
        statusEl.textContent = 'Send error: ' + (res.description || res.error_code);
        statusEl.className = 'error';
      }
    })
    .catch(e => {
      log(`Network error: ${e.message}`, 'error');
      statusEl.textContent = 'Network error: ' + e.message;
      statusEl.className = 'error';
    });
}
